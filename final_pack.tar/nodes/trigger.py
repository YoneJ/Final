# trigger_node.py
import rospy
from std_msgs.msg import Bool

def trigger_path_planning():
    rospy.init_node('trigger_node')
    trigger_pub = rospy.Publisher('path_trigger', Bool, queue_size=10)
    rate = rospy.Rate(1)  # Trigger every second for testing

    while not rospy.is_shutdown():
        trigger_pub.publish(True)
        rospy.sleep(5)  # Trigger every 5 seconds

if __name__ == '__main__':
    try:
        trigger_path_planning()
    except rospy.ROSInterruptException:
        pass
